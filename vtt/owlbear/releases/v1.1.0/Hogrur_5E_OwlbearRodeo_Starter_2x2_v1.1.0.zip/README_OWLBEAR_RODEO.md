# BAALPHEMOR GAMING — Die Hogrur / The Hogrur (Owlbear Rodeo 2.0 Pack v1.1.0)

## Zwei Wege in Owlbear Rodeo 2.0 (`owlbear.rodeo`)

### Weg A: Direkt per Live-Extension (`BAALPHEMOR 5E Vault`) — 1-Klick `2×2` Spawner & Statblocks!
1. Öffne deinen Raum auf https://www.owlbear.rodeo -> klicke unten links auf **Extensions (`•••` -> Add Extension)**.
2. Füge diese Manifest-URL ein:
   `https://baalphemor-gaming.de/vtt/owlbear/baalphemor-vault/manifest.json`
3. Klicke oben links auf das **BAALPHEMOR**-Wappen -> wähle Sprache (`DE / EN / ES / FR`), lies die Werteblöcke direkt im Seitenpanel und setze jeden Hogrur mit **1 Klick automatisch im exakten `2×2` Large-Maßstab** mitten auf deine aktive Karte!

### Weg B: Bulk Drag-&-Drop dieses ZIP-Ordners in deinen Owlbear Asset-Manager
1. Entpacke dieses Archiv. Alle Tokens tragen bereits das Suffix `*_2x2.png` bzw. `*_2x2.webm`.
2. Öffne in Owlbear Rodeo das **Image Dock (`Images` / `Characters`)** -> lege einen Ordner `BAALPHEMOR - Hogrur (2x2)` an -> ziehe die gewünschten Tokens per Drag-&-Drop hinein und stelle `Default Grid Size` auf `2×2` (`dpi: 256` bei `512×512 px`).
   *(Hinweis: Animierte VP9-Alpha-`.webm`-Tokens werden von Owlbear Rodeo 2.0 nativ mit Transparenz abgespielt!)*

Kontakt & Feedback: **info@baalphemor.de** · https://baalphemor-gaming.de · https://www.patreon.com/baalphemor
