# BAALPHEMOR GAMING — Die Hogrur / The Hogrur (Foundry VTT 5e Starter Module)

**Modul-ID / Module ID:** `baalphemor-hogrur-5e-starter` | **Version:** `1.1.0`  
**Kompatibilität / Compatibility:** Foundry VTT **v12 / v13 / v14** (`dnd5e` ab v3.0+)  
**Sprachen / Languages:** **Deutsch (`DE`) · English (`EN`) · Español (`ES`) · Français (`FR`)**  
**Autor & Kontakt:** **Michael Stahlschmidt ("BAALPHEMOR")** — **info@baalphemor.de** · https://baalphemor-gaming.de · https://www.patreon.com/baalphemor · https://baalphemor.itch.io

## Inhalt des kostenlosen Starter-Moduls
- **4 spielfertige `2×2` Large 5e-Akteure** in 4 Sprachen (`DE`, `EN`, `ES`, `FR`) + **Spezies, Archetyp, 3 Waffen, Munition & Übergrößen-Regeljournal**.
- **10 statische `512×512` Starter-Tokens** + **4 Portraits** + **1 Original-SFX-Hörprobe** (`hogrur_cannon_tribarrel_blast.ogg`).
- **Vollpaket (`baalphemor-hogrur-5e` mit 136 PNGs, 60 animierten VP9-Alpha-WebMs & 5 SFX):** https://www.patreon.com/baalphemor & https://baalphemor.itch.io/the-hogrur-5e-foundry-vtt
