/**
 * BAALPHEMOR GAMING — Die Hogrur / The Hogrur (5e Companion Module)
 * Kompatibel mit Foundry VTT v12, v13 & v14.
 * Stellt `game.baalphemorHogrur.importAll("de" | "en" | "both")` bereit und bietet beim ersten Start
 * für die Spielleitung (GM) einen 1-Klick-Import der 4 vorkonfigurierten 2x2-Akteure,
 * sämtlicher Charakterbau-Items (Spezies, Archetyp, Waffen), Übergrößen-Journal & 5-Track-SFX-Soundboard.
 */
const MODULE_ID = "baalphemor-hogrur-5e-starter";

async function importHogrurPack(lang = "both") {
  if (!game.user?.isGM) return;
  const resp = await fetch(`modules/${MODULE_ID}/packs/hogrur_actors_5e_import.json`);
  if (!resp.ok) throw new Error(`Konnte hogrur_actors_5e_import.json nicht laden (${resp.status})`);
  const data = await resp.json();

  let folder = game.folders?.find(f => f.type === "Actor" && f.flags?.[MODULE_ID]?.isHogrurRoot);
  if (!folder) {
    folder = await Folder.create({
      name: "Die Hogrur / The Hogrur (5e)",
      type: "Actor",
      color: "#7a3b1e",
      flags: { [MODULE_ID]: { isHogrurRoot: true } }
    });
  }

    const pick = (prefix) => {
      if (["de", "en", "es", "fr"].includes(lang)) return data[`${prefix}_${lang}`] || [];
      return data[prefix] || [];
    };

  const selected = pick("actors");
  let createdCount = 0;
  for (const src of selected) {
    const exists = game.actors?.find(a => a.name === src.name && a.folder?.id === folder.id);
    if (!exists) {
      const docData = foundry.utils.deepClone(src);
      delete docData._id;
      docData.folder = folder.id;
      await Actor.create(docData);
      createdCount += 1;
    }
  }

  let itemFolder = game.folders?.find(f => f.type === "Item" && f.flags?.[MODULE_ID]?.isHogrurItemRoot);
  if (!itemFolder) {
    itemFolder = await Folder.create({
      name: "Die Hogrur — Spezies, Archetyp & Arsenal (5e)",
      type: "Item",
      color: "#7a3b1e",
      flags: { [MODULE_ID]: { isHogrurItemRoot: true } }
    });
  }
  const selItems = pick("items");
  for (const itSrc of selItems) {
    const exIt = game.items?.find(i => i.name === itSrc.name && i.folder?.id === itemFolder.id);
    if (!exIt) {
      const itData = foundry.utils.deepClone(itSrc);
      delete itData._id;
      itData.folder = itemFolder.id;
      await Item.create(itData);
    }
  }

  const selJournals = pick("journals");
  for (const jSrc of selJournals) {
    const exJ = game.journal?.find(j => j.name === jSrc.name);
    if (!exJ) {
      const jData = foundry.utils.deepClone(jSrc);
      delete jData._id;
      jData.pages = (jData.pages || []).map(p => { const cp = foundry.utils.deepClone(p); delete cp._id; return cp; });
      await JournalEntry.create(jData);
    }
  }

  const plExists = game.playlists?.find(p => p.name === data.playlist.name);
  if (!plExists && data.playlist) {
    const plData = foundry.utils.deepClone(data.playlist);
    delete plData._id;
    plData.sounds = (plData.sounds || []).map(s => {
      const c = foundry.utils.deepClone(s);
      delete c._id;
      return c;
    });
    await Playlist.create(plData);
  }

  ui.notifications?.info(`BAALPHEMOR Hogrur 5e: ${createdCount} Akteur(e) (2x2 Large), Charakterbau-Items, Regeln & SFX bereit!`);
}

Hooks.once("init", () => {
  game.settings.register(MODULE_ID, "autoPromptShown", {
    name: "Hogrur Initial Import Prompt",
    scope: "world",
    config: false,
    type: Boolean,
    default: false
  });
});

Hooks.once("ready", async () => {
  game.baalphemorHogrur = { importAll: importHogrurPack };
  if (!game.user?.isGM) return;
  if (game.settings.get(MODULE_ID, "autoPromptShown")) return;
  await game.settings.set(MODULE_ID, "autoPromptShown", true);

  new Dialog({
    title: "BAALPHEMOR GAMING — Hogrur 5e Starter Pack (DE / EN / ES / FR)",
    content: `<p>Möchtest du die <strong>4 vorkonfigurierten 2×2-Hogrur-Akteure</strong>, Charakterbau-Items, Übergrößen-Regeln und die <strong>Kanonendonner-SFX-Hörprobe</strong> (Vollpaket mit 60 WebMs &amp; 136 PNGs auf patreon.com/baalphemor &amp; baalphemor.itch.io) importieren? / Import 2×2 Hogrur Actors, Character Options &amp; SFX?</p><p style="font-size:0.85em;opacity:0.85;">Feedback &amp; Kontakt: <strong>info@baalphemor.de</strong> · baalphemor-gaming.de</p>`,
    buttons: {
      de: { label: "Deutsch (DE)", callback: () => importHogrurPack("de") },
      en: { label: "English (EN)", callback: () => importHogrurPack("en") },
      es: { label: "Español (ES)", callback: () => importHogrurPack("es") },
      fr: { label: "Français (FR)", callback: () => importHogrurPack("fr") },
      later: { label: "Später / Later" }
    },
    default: "de"
  }).render(true);
});
